# Ansible Collection - iida.local

ネットワーク機器のコンフィグを比較して差分を生成するモジュール。
対象装置には接続しない。

Ansible Collection generate config diff

## Requirements

- Ansible 2.9 or later

## Install/Uninstall

1. Clone this repository

```bash
git clone https://github.com/takamitsu-iida/ansible_collections.iida.local.git
```

1. Build collection

```bash
make build
```

1. Install collection to your personal environment

The collection will be installed to ~/.ansible/collections/ansible_collections/

```bash
make install
```

## Example

playbook

```yml

```

execution example

```bash

```
